#include "avro_private.h"
#include <stdio.h>
#include <unistd.h>

int main(void)
{
	return 0;
}
